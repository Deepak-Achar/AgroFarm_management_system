import numpy as np
l1=[[10,20]]